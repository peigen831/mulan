Mulan's 1.5.0 release contains:

A jar file with Mulan classes (mulan.jar)
A jar file with Weka classes, upon which Mulan is built (weka-3.7.10.jar)
A jar file with Clus classes (Clus.jar)
A jar file with Mulan sources (mulan-src.jar)
A folder with the API reference documentation for offline inspection (apidoc/)
A folder with a sample dataset (data/)
A change log file with changes from previous Mulan versions (changelog.txt)
A license file (license.txt)
An xml build file (build.xml)
This readme file (readme.txt)

To get started with Mulan please refer to our online documentation:
http://mulan.sourceforge.net/starting.html
